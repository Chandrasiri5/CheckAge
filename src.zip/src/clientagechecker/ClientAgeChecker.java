import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

public class ClientAgeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Welcome message
        System.out.println("Welcome to the Sri Lanka National ID Eligibility Checker!");

        while (true) {
            // Display menu
            System.out.println("\nMenu:");
            System.out.println("1. Add a new client");
            System.out.println("2. View all clients");
            System.out.println("3. Search for a client by name");
            System.out.println("4. Exit");
            System.out.print("Choose an option (1-4): ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addNewClient(scanner);
                    break;
                case 2:
                    viewAllClients();
                    break;
                case 3:
                    searchClientByName(scanner);
                    break;
                case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice! Please choose a valid option.");
            }
        }
    }

    // Add a new client
    private static void addNewClient(Scanner scanner) {
        System.out.print("Enter client's name: ");
        String name = scanner.nextLine();

        System.out.print("Enter client's date of birth (YYYY-MM-DD): ");
        String dobInput = scanner.nextLine();

        try {
            // Parse the date of birth
            LocalDate dob = LocalDate.parse(dobInput);

            // Calculate age
            int age = Period.between(dob, LocalDate.now()).getYears();

            // Determine eligibility
            String eligibility = (age >= 18) ? "Eligible" : "Not Eligible";

            // Display results
            System.out.println("\nHi " + name + ", your age is: " + age);
            if (age >= 18) {
                System.out.println("You are eligible to issue a National ID.");
            } else {
                System.out.println("You are not eligible for a National ID yet.");
            }

            // Save to database
            saveToDatabase(name, dobInput, age, eligibility);

        } catch (Exception e) {
            System.out.println("Invalid date format! Please use the format YYYY-MM-DD.");
        }
    }

    // View all clients
    private static void viewAllClients() {
        String url = "jdbc:mysql://localhost:3306/ClientDB";
        String user = "root"; // Replace with your MySQL username
        String password = "Imesh/@1234"; // Replace with your MySQL password

        String query = "SELECT * FROM clients";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            System.out.println("\n--- List of Clients ---");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Date of Birth: " + rs.getDate("dob"));
                System.out.println("Age: " + rs.getInt("age"));
                System.out.println("Eligibility: " + rs.getString("eligibility"));
                System.out.println("-------------------------");
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving clients: " + e.getMessage());
        }
    }

    // Search for a client by name
    private static void searchClientByName(Scanner scanner) {
        System.out.print("Enter the client's name to search: ");
        String searchName = scanner.nextLine();

        String url = "jdbc:mysql://localhost:3306/ClientDB";
        String user = "root"; // Replace with your MySQL username
        String password = "Imesh/@1234"; // Replace with your MySQL password

        String query = "SELECT * FROM clients WHERE name LIKE ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, "%" + searchName + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                System.out.println("\n--- Search Results ---");
                boolean found = false;
                while (rs.next()) {
                    found = true;
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Date of Birth: " + rs.getDate("dob"));
                    System.out.println("Age: " + rs.getInt("age"));
                    System.out.println("Eligibility: " + rs.getString("eligibility"));
                    System.out.println("-------------------------");
                }
                if (!found) {
                    System.out.println("No clients found with the name: " + searchName);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error searching for client: " + e.getMessage());
        }
    }

    // Save client details to MySQL database
    
    private static void saveToDatabase(String name, String dob, int age, String eligibility) {
        String url = "jdbc:mysql://localhost:3306/ClientDB";
        String user = "root"; // Replace with your MySQL username
        String password = "Imesh/@1234"; // Replace with your MySQL password

        String insertQuery = "INSERT INTO clients (name, dob, age, eligibility) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, name);
            pstmt.setDate(2, Date.valueOf(dob));
            pstmt.setInt(3, age);
            pstmt.setString(4, eligibility);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Client details saved to database successfully!");
            }

        } catch (SQLException e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }
    }
}
